
/*************************************************************************
Copyright:   HZ.
Author:		 Hu Yaowu
Date:		 2015-4-23
Mail:        dongtingyueh@163.com
Description: __T_BILATERAL_FILTER__ .
*************************************************************************/
#ifndef __T_BILATERAL_FILTER__
#define __T_BILATERAL_FILTER__


#ifdef _MSC_VER

#ifdef __cplusplus
#define EXPORT extern "C" _declspec(dllexport)
#else
#define EXPORT __declspec(dllexport)
#endif

EXPORT void f_Bilateralfilter(unsigned char* pImage, int nWidth, int nHeight, int nStride, double std);


#else

#ifdef __cplusplus
extern "C" {
#endif    

    void f_Bilateralfilter(unsigned char* pImage, int nWidth, int nHeight, int nStride, double std);

#ifdef __cplusplus
}
#endif


#endif



#endif
